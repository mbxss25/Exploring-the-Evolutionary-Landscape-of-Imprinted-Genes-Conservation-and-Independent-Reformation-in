import os
from Bio import SeqIO
import pandas as pd

def extract_sequences(subject_dir, blast_results_dir, output_dir):
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Iterate through each BLAST result file in the directory
    for blast_file in os.listdir(blast_results_dir):
        if blast_file.endswith('.txt'):
            gene_cluster = blast_file.replace('_blast_results_filtered.txt', '')  # Adjust the replacement to match the actual file naming
            fasta_file = os.path.join(subject_dir, f"{gene_cluster}_cluster.fasta")
            output_fasta = os.path.join(output_dir, f"{gene_cluster}_final.fasta")
            
            # Check if the FASTA file exists before proceeding
            if not os.path.exists(fasta_file):
                print(f"No FASTA file found for {fasta_file}")
                continue
            
            # Read the BLAST results to get the list of sequence IDs
            blast_df = pd.read_csv(os.path.join(blast_results_dir, blast_file), sep='\t', header=None, usecols=[1])
            blast_df.columns = ['sseqid']
            accession_numbers = set(blast_df['sseqid'])
            
            # Load the sequences from the FASTA file
            sequences_to_write = []
            for seq in SeqIO.parse(fasta_file, 'fasta'):
                if seq.id in accession_numbers:
                    sequences_to_write.append(seq)
                
            # Write the filtered sequences to the output FASTA file
            SeqIO.write(sequences_to_write, output_fasta, 'fasta')

# Define the directories
subject_dir = './merged_clusters'
blast_results_dir = './final_blast'
output_dir = './ready_clusters'

# Extract sequences
extract_sequences(subject_dir, blast_results_dir, output_dir)

