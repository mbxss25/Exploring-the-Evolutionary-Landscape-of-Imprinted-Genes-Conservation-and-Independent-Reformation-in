import os
import pandas as pd

def process_single_blast_file(file_path, output_suffix='_filtered.txt'):
    # Define column names based on BLAST output format (assuming '-outfmt 6')
    columns = ['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen',
               'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore']
    df = pd.read_csv(file_path, sep='\t', names=columns, dtype={'evalue': float})
    
    # Calculate the absolute difference from the target e-value of e^-7
    target_evalue = 1e-7
    df['evalue_diff'] = (df['evalue'] - target_evalue).abs()
    
    # Sort and drop duplicates based on 'sseqid' while keeping the entry closest to e^-7
    df_sorted = df.sort_values(by=['sseqid', 'evalue_diff'])
    df_filtered = df_sorted.drop_duplicates(subset=['sseqid'], keep='first')
    
    # Write to a new file with a specific suffix
    new_file_path = file_path.replace('.txt', output_suffix)
    df_filtered.to_csv(new_file_path, index=False, sep='\t', header=False)

def process_all_blast_outputs(directory):
    for filename in os.listdir(directory):
        if filename.endswith('_results.txt'):  # Check for files ending with specific suffix
            file_path = os.path.join(directory, filename)
            print(f'Processing {file_path}...')
            process_single_blast_file(file_path)
            print(f'Finished processing {file_path}')

# Set the directory containing BLAST output files
blast_output_directory = './blast_results'
process_all_blast_outputs(blast_output_directory)


