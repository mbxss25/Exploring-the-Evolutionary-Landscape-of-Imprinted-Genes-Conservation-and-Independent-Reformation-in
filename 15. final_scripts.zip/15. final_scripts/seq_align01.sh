#!/bin/bash

#SBATCH --partition=defq
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=50g
#SBATCH --time=10:00:00
#SBATCH --job-name=seq_align01
#SBATCH --output=/gpfs01/home/mbxss25/slurm-%x-%j.out
#SBATCH --mail-type=ALL
#SBATCH --mail-user=mbxss25@exmail.nottingham.ac.uk

python seq_align01.py

echo "done prcoessing"

