#!/bin/bash

#SBATCH --partition=defq
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=50g
#SBATCH --time=10:00:00
#SBATCH --job-name=all_blast
#SBATCH --output=/gpfs01/home/mbxss25/slurm-%x-%j.out
#SBATCH --mail-type=ALL
#SBATCH --mail-user=mbxss25@exmail.nottingham.ac.uk

# Load the BLAST module
module load blast-uoneasy/2.14.1-gompi-2023a

# Define directories
QUERY_DIR="./query_seqs"
DB_DIR="./new_blastmkdata"
OUT_DIR="./blast_results"

# Ensure output directory exists
mkdir -p ${OUT_DIR}

# Run BLAST for the specified query and database
blastp -query ${QUERY_DIR}/ascl2_extracted.fa -db ${DB_DIR}/ascl2_cluster -out ${OUT_DIR}/ascl2_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/casd1_extracted.fa -db ${DB_DIR}/casd1_cluster -out ${OUT_DIR}/casd1_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/cd81_extracted.fa -db ${DB_DIR}/cd81_cluster -out ${OUT_DIR}/cd81_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/cdh15_extracted.fa -db ${DB_DIR}/cdh15_cluster -out ${OUT_DIR}/cdh15_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/cdkn1c_extracted.fa -db ${DB_DIR}/cdkn1c_cluster -out ${OUT_DIR}/cdkn1c_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/commd1_extracted.fa -db ${DB_DIR}/commd1_cluster -out ${OUT_DIR}/commd1_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/dcn_extracted.fa -db ${DB_DIR}/dcn_cluster -out ${OUT_DIR}/dcn_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/dhcr7_extracted.fa -db ${DB_DIR}/dhcr7_cluster -out ${OUT_DIR}/dhcr7_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/dio3_extracted.fa -db ${DB_DIR}/dio3_cluster -out ${OUT_DIR}/dio3_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/dlk1_extracted.fa -db ${DB_DIR}/dlk1_cluster -out ${OUT_DIR}/dlk1_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/dlx5_extracted.fa -db ${DB_DIR}/dlx5_cluster -out ${OUT_DIR}/dlx5_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/dscam_extracted.fa -db ${DB_DIR}/dscam_cluster -out ${OUT_DIR}/dscam_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/gab1_extracted.fa -db ${DB_DIR}/gab1_cluster -out ${OUT_DIR}/gab1_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/gatm_extracted.fa -db ${DB_DIR}/gatm_cluster -out ${OUT_DIR}/gatm_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/glis3_extracted.fa -db ${DB_DIR}/glis3_cluster -out ${OUT_DIR}/glis3_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/grb10_extracted.fa -db ${DB_DIR}/grb10_cluster -out ${OUT_DIR}/grb10_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/h13_extracted.fa -db ${DB_DIR}/h13_cluster -out ${OUT_DIR}/h13_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/htr2a_extracted.fa -db ${DB_DIR}/htr2a_cluster -out ${OUT_DIR}/htr2a_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/igf2_extracted.fa -db ${DB_DIR}/igf2_cluster -out ${OUT_DIR}/igf2_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/igf2r_extracted.fa -db ${DB_DIR}/igf2r_cluster -out ${OUT_DIR}/igf2r_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/impact_extracted.fa -db ${DB_DIR}/impact_cluster -out ${OUT_DIR}/impact_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/lin28b_extracted.fa -db ${DB_DIR}/lin28b_cluster -out ${OUT_DIR}/lin28b_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/lrrtm1_extracted.fa -db ${DB_DIR}/lrrtm1_cluster -out ${OUT_DIR}/lrrtm1_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/naa60_extracted.fa -db ${DB_DIR}/naa60_cluster -out ${OUT_DIR}/naa60_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/osbpl5_extracted.fa -db ${DB_DIR}/osbpl5_cluster -out ${OUT_DIR}/osbpl5_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/plagl1_extracted.fa -db ${DB_DIR}/plagl1_cluster -out ${OUT_DIR}/plagl1_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/pon2_extracted.fa -db ${DB_DIR}/pon2_cluster -out ${OUT_DIR}/pon2_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/pon3_extracted.fa -db ${DB_DIR}/pon3_cluster -out ${OUT_DIR}/pon3_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/rb1_extracted.fa -db ${DB_DIR}/rb1_cluster -out ${OUT_DIR}/rb1_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/sfmbt2_extracted.fa -db ${DB_DIR}/sfmbt2_cluster -out ${OUT_DIR}/sfmbt2_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/slc38a4_extracted.fa -db ${DB_DIR}/slc38a4_cluster -out ${OUT_DIR}/slc38a4_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/tssc4_extracted.fa -db ${DB_DIR}/tssc4_cluster -out ${OUT_DIR}/tssc4_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/zc3h12c_extracted.fa -db ${DB_DIR}/zc3h12c_cluster -out ${OUT_DIR}/zc3h12c_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/zfat_extracted.fa -db ${DB_DIR}/zfat_cluster -out ${OUT_DIR}/zfat_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/zim2_extracted.fa -db ${DB_DIR}/zim2_cluster -out ${OUT_DIR}/zim2_blast_results.txt -evalue 1e-7 -outfmt 6
blastp -query ${QUERY_DIR}/znf597_extracted.fa -db ${DB_DIR}/znf597_cluster -out ${OUT_DIR}/znf597_blast_results.txt -evalue 1e-7 -outfmt 6


echo "BLAST search completed for ampd3. Results are saved in ${OUT_DIR}/ampd3_blast_results.txt"

